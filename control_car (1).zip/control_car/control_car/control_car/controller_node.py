import rclpy
from geometry_msgs.msg import Twist
import math
from rclpy.node import Node
from std_msgs.msg import Float32


class ControllerNode(Node):
    def __init__(self):
        super().__init__('controller_node')
        qos_profile = rclpy.qos.qos_profile_sensor_data
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.angle_subscription = self.create_subscription(Float32, 'odom_angle', self.angle_callback, qos_profile)
        self.x_subscription = self.create_subscription(Float32, 'odom_x', self.x_callback, qos_profile)
        self.y_subscription = self.create_subscription(Float32, 'odom_y', self.y_callback, qos_profile)
        self.angulo_actual = 0.0
        self.x_actual = 0.0
        self.y_actual = 0.0
        self.timer_period = 0.2
        self.timer = self.create_timer(self.timer_period, self.controller_timer_callback)
        self.contador = 0
        self.kp = 0.05  # Adjust this value as needed
        self.punto_deseados = [[5, 0], [5, 5]]
        twist_msg = Twist()
        twist_msg.linear.x = 0.0
        twist_msg.angular.z = 0.0

    def angle_callback(self, msg):
        self.angulo_actual = msg.data

    def x_callback(self, msg):
        self.x_actual = msg.data

    def y_callback(self, msg):
        self.y_actual = msg.data

    def controller_timer_callback(self):
        twist_msg = Twist()

        # Calculate distances from current point to waypoints
        delta_y = self.punto_deseados[self.contador][1] - self.y_actual
        delta_x = self.punto_deseados[self.contador][0] - self.x_actual
        distancia_calculada = math.sqrt((delta_y ** 2) + (delta_x ** 2))

        # Calculate angles from initial point to waypoints
        # angle_radianes_deseado = math.atan2(delta_y, delta_x) - self.angulo_actual

        # Calculate errors
        error_angulos = math.atan2(self.punto_deseados[self.contador][1],self.punto_deseados[self.contador][0]) - self.angulo_actual
        error_distancia = distancia_calculada 

        # Calculate final velocities using proportional control
        velocidad_linear_final =  0.04 * error_distancia
        velocidad_angular_final =  0.1 * error_angulos
        if (velocidad_linear_final > 0.3):
            velocidad_linear_final2 = 0.2
            twist_msg.linear.x = velocidad_linear_final2
        elif (velocidad_angular_final > 0.3):
            velocidad_angular_final2 = 0.2
            twist_msg.angular.z = velocidad_angular_final2
        else:
            twist_msg.linear.x = velocidad_linear_final
            twist_msg.angular.z = velocidad_angular_final   


        # Publish twist message
        self.publisher.publish(twist_msg)
        print("Error distancia: ",error_distancia)
        print("Error angulo: ", error_angulos)
        print("Angulo Actual: ", self.angulo_actual)
        print("Velocidad linear final: " ,velocidad_linear_final)
        print("Velocidad Angular final: ",velocidad_angular_final)
        print(self.contador)

        # Increment counter
        if ((self.x_actual <= 0.1 + self.punto_deseados[self.contador][0] and self.x_actual >= self.punto_deseados[self.contador][0] - 0.1) and (self.y_actual <= self.punto_deseados[self.contador][1] + 0.1 and self.y_actual >= self.punto_deseados[self.contador][1] - 0.1)):
            
            self.contador += 1

        
        if (self.contador == len(self.punto_deseados)):
            twist_msg.linear.x == 0.0
            twist_msg.angular.z == 0.0


def main(args=None):
    rclpy.init(args=args)
    controller_node = ControllerNode()
    try:
        rclpy.spin(controller_node)
    except KeyboardInterrupt:
        pass
    finally:
        controller_node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
