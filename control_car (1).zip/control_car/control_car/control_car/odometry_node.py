import rclpy
import math
from rclpy.node import Node
from std_msgs.msg import Float32


class OdometryNode(Node):
    def __init__(self):
        super().__init__('odometry_node')
        self.angle_publisher = self.create_publisher(Float32, 'odom_angle', 10)
        self.x_publisher = self.create_publisher(Float32, 'odom_x', 10)
        self.y_publisher = self.create_publisher(Float32, 'odom_y', 10)

        qos_profile = rclpy.qos.qos_profile_sensor_data
        self.wl_subscription = self.create_subscription(Float32, '/VelocityEncL', self.wl_callback, qos_profile)
        self.wr_subscription = self.create_subscription(Float32, '/VelocityEncR', self.wr_callback, qos_profile)
        self.wl = 0.0
        self.wr = 0.0
        self.angulo_actual = 0.0
        self.x_actual = 0.0
        self.y_actual = 0.0
        self.timer_period = 0.1
        self.timer = self.create_timer(self.timer_period, self.odometry_node)

    def wl_callback(self, msg):
        self.wl = msg.data

    def wr_callback(self, msg):
        self.wr = msg.data

    def odometry_node(self):
        wl = self.wl
        wr = self.wr
        radio_llanta = 5
        distancia_llantas = 18
        diferencial_tiempo = 0.01
        #angulo_actual = self.angulo_actual

        self.angulo_actual = self.angulo_actual + (radio_llanta * ((wr - wl) / distancia_llantas) * diferencial_tiempo)
        self.x_actual = ((radio_llanta * ((wr + wl) / 2.0) * diferencial_tiempo) * math.cos(self.angulo_actual)) + self.x_actual
        self.y_actual = ((radio_llanta * ((wr + wl) / 2.0) * diferencial_tiempo) * math.sin(self.angulo_actual)) + self.y_actual

        # Publish the angle
        angle_msg = Float32()
        angle_msg.data = self.angulo_actual
        self.angle_publisher.publish(angle_msg)

        # Publish the x value
        x_msg = Float32()
        x_msg.data = self.x_actual
        self.x_publisher.publish(x_msg)

        # Publish the y value
        y_msg = Float32()
        y_msg.data = self.y_actual
        self.y_publisher.publish(y_msg)

        print("Angulo Actual: ", self.angulo_actual)
        print("Posición X Actual: ", self.x_actual)
        print("Posición Y Actual: ", self.y_actual)
        print("Valor encoder izq: ",wl)
        print("Valor encoder der: ",wr)


def main(args=None):
    rclpy.init(args=args)
    odometry_subscriber = OdometryNode()
    try:
        rclpy.spin(odometry_subscriber)
    except KeyboardInterrupt:
        pass
    finally:
        odometry_subscriber.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
