import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import time

class LinearVelocityPublisher(Node):
    def __init__(self):
        super().__init__('angular_velocity_publisher')
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.timer_period = 0.1
        self.timer = self.create_timer(self.timer_period, self.timer_callback)
        self.angular_velocity_z = 0.0
        self.current_time = time.time()
        self.start_time = time.time()
        self.filename = 'velocity_log.txt'

    def timer_callback(self):
        new_time = time.time()
        dt = new_time - self.current_time
        self.current_time = new_time

        elapsed_time = new_time - self.start_time

        if elapsed_time < 5:
            target_velocity = 0.05
        elif 5 <= elapsed_time < 10:
            target_velocity = 0.1
        elif 10 <= elapsed_time < 15:
            target_velocity = 0.15
        elif 15 <= elapsed_time <20 :
            target_velocity = 0.2
        elif 20 <= elapsed_time < 25:
            target_velocity = 0.25
        elif 25 <= elapsed_time < 30:
            target_velocity = 0.3
        else:
            target_velocity = 0.0


        # Set velocity directly to the target
        self.angular_velocity_z = target_velocity

        # Create Twist message
        twist_msg = Twist()
        twist_msg.angular.z = self.angular_velocity_z

        # Publish Twist message
        self.publisher.publish(twist_msg)

        # Write time and velocity to file
        with open(self.filename, 'a') as f:
            f.write(f"Time: {elapsed_time:.2f}s, Velocity: {self.angular_velocity_z:.2f}\n")

def main(args=None):
    rclpy.init(args=args)
    angular_velocity_publisher = LinearVelocityPublisher()
    rclpy.spin(angular_velocity_publisher)
    angular_velocity_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
