import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64
import math
import time

class ConstantTwistPublisher(Node):
    def __init__(self):
        super().__init__('constant_twist_publisher')
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.wl_subscription = self.create_subscription(Float64, '/wl', self.waypoints_callback, 10)
        self.wr_subscription = self.create_subscription(Float64, '/wr', self.waypoints_callback, 10)
        self.wl = 0.0
        self.wr = 0.0


        self.timer_period_controller = 0.1
        self.timer_desired_angle = self.create_timer(self.timer_period_controller, self.waypoints_callback)
        

        
    def waypoints_callback(self,msg):

        if msg.topic == '/wl':
            self.wl = msg.data  # Store received left wheel velocity
        elif msg.topic == '/wr':
            self.wr = msg.data  # Store received right wheel velocity

        twist_msg = Twist()
        i = 0
        radio_llanta = 5.0
        longitud_rueda = 18.0
        twist_msg.linear.x = 0.0
        twist_msg.angular.z = 0.0
        punto_inicial = [0, 0]
        punto_deseado = [[10, 0],[10,10],[0,10],[0,0]]
        contador = 0
        wl = self.wl
        wr = self.wr
        tiempo_parametro = 10.0
        tiempo_angulo_parametro = 5.0
        t_60cm_distancia = 11.2775
        # distancia_calc = 60.0
        t_90grados = 2.856
        # angulo_calc = 90.0

        # Formulas Manchester RObotics
        distancia_calc = radio_llanta * 0.1 * ((wr+wl)/2)
        angulo_calc = radio_llanta * ((wr - wl)/longitud_rueda)* 0.1



        if (contador == 0):
            delta_x = punto_deseado[0][0] - punto_inicial[0]
            delta_y = punto_deseado[0][1] - punto_inicial[1]
        else:
            delta_x = punto_deseado[i][0] - punto_deseado[i-1][0]
            delta_y = punto_deseado[i][1] - punto_deseado[i-1][1]



        # Calculando el angulo necesitado
        
        # angle_radianes = math.atan2(delta_y, delta_x)
        # Nueva Formula
        angle_radianes_nuevo = radio_llanta * ((wl - wr)/longitud_rueda)
        # angle_grados = angle_radianes * (180 / math.pi)
        # t_deseado_angulo = (angle_grados * t_90grados) / angulo_calc
        t_deseado_angulo = abs(t_deseado_angulo)

        # Calcula Distancia
        distancia_deseada = math.sqrt((delta_x * delta_x)+(delta_y * delta_y))
        # Nueva formula implementada
        # t_distancia_deseada = (distancia_deseada * t_60cm_distancia)/distancia_calc
        t_distancia_deseada = abs(t_distancia_deseada)


        # Start time
        start_time = time.time()

        # Perform some action for the specified duration
        while time.time() - start_time < t_deseado_angulo:
            # Create a Twist message with constant angular velocity
            twist_msg.angular.z = 0.1
            # Publish Twist message
            self.publisher.publish(twist_msg)
            time.sleep(0.1)  # Adjust sleep time as needed

        # Action completed
        twist_msg.angular.z = 0.0

        start_time_distancia = time.time()
        while time.time() - start_time_distancia < t_distancia_deseada:
            twist_msg.linear.x = 0.1
            self.publisher.publish(twist_msg)
            time.sleep(0.1)

        twist_msg.angular.z = 0.0
        twist_msg.linear.x = 0.0    
        self.publisher.publish(twist_msg)
        print("Action completed after", t_deseado_angulo, "seconds")
        i = i + 1

def main(args=None):
    rclpy.init(args=args)
    constant_twist_publisher = ConstantTwistPublisher()
    rclpy.spin(constant_twist_publisher)
    constant_twist_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()