import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32
import math
import time

class ConstantTwistPublisher(Node):
    def __init__(self):
        super().__init__('odometry_node')
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        qos_profile = rclpy.qos.qos_profile_sensor_data
        self.wl_subscription = self.create_subscription(Float32, '/wl', self.wl_callback, qos_profile)
        self.wr_subscription = self.create_subscription(Float32, '/wr', self.wr_callback, qos_profile)
        self.wl = 0.0
        self.wr = 0.0
        self.current_time = time.time()
        self.start_time = time.time()
        self.timer_period_controller = 0.1
        self.timer_desired_angle = self.create_timer(self.timer_period_controller, self.timer_callback)

    def wl_callback(self,msg):
        self.wl = msg.data

    def wr_callback(self,msg):
        self.wr = msg.data


    def timer_callback(self):
        twist_msg = Twist()
        twist_msg.linear.x = 0.0
        twist_msg.angular.z = 0.0
        wl = self.wl
        wr = self.wr
        radio_llanta = 5
        distancia_llantas = 18
        diferencial_tiempo = 0.1
        contador = 0

        new_time = time.time()
        dt = new_time - self.current_time
        self.current_time = new_time

        elapsed_time = new_time - self.start_time

        if elapsed_time < 5:
            twist_msg.linear.x = 0.05
        elif 5 <= elapsed_time < 10:
            twist_msg.linear.x = 0.1
        elif 10 <= elapsed_time < 15:
            twist_msg.linear.x = 0.15
        elif 15 <= elapsed_time <20 :
            twist_msg.linear.x = 0.2
        elif 20 <= elapsed_time < 25:
            twist_msg.linear.x = 0.25
        elif 25 <= elapsed_time < 30:
            twist_msg.linear.x = 0.3
        else:
            twist_msg.linear.x = 0.0

        self.publisher.publish(twist_msg)




        # Odometria
        # Calcular las posiciones actuales del linear y angular del carro
        angulo_actual = 00.0
        x_actual = 0.0
        y_actual = 0.0

        angulo_actual = angulo_actual + (radio_llanta*((wr-wl)*distancia_llantas)*diferencial_tiempo)
        x_actual = ((radio_llanta*((wr+wl)/2.0)*diferencial_tiempo)* math.cos(angulo_actual)) + x_actual
        y_actual = ((radio_llanta*((wr+wl)/2.0)*diferencial_tiempo)* math.sin(angulo_actual)) + y_actual


        # Waypoints, Sacando su distancia inicial al waypoint
        punto_deseados = [[10,0],[10,10],[0,10],[0,0]]


        # Controlador
        # Calcular distancias de punto acutal a waypoints
        delta_y = punto_deseados[contador + 1][1] - y_actual
        delta_x = punto_deseados[contador + 1][0] - x_actual
        distancia_calculada = math.sqrt((delta_y * delta_y)+(delta_x * delta_x))

        # Calcular angulos de punto inicial a waypoints
        angle_radianes_deseado = math.atan2(delta_y, delta_x) - angulo_actual



        error_angulos = angle_radianes_deseado
        error_distancia = distancia_calculada

        velocidad_final = 1 * error_distancia
        velocidad_angular_final = 1 * error_angulos

        print(wl)
        print(wr)
        print(velocidad_angular_final)
        print(velocidad_final)
        
        contador = contador + 1
        

        

        

def main(args=None):
    rclpy.init(args=args)
    constant_twist_publisher = ConstantTwistPublisher()
    rclpy.spin(constant_twist_publisher)
    constant_twist_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
