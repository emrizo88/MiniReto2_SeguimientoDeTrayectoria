import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32


class WheelSubscriber(Node):
    def __init__(self):
        super().__init__('wheel_subscriber')
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        qos_profile = rclpy.qos.qos_profile_sensor_data
        self.wl_subscription = self.create_subscription(Float32, '/VelocityEncL', self.wl_callback, qos_profile)
        self.wr_subscription = self.create_subscription(Float32, '/VelocityEncR', self.wr_callback, qos_profile)
        self.wl = 0.0
        self.wr = 0.0
        self.timer_period = 0.1
        self.timer = self.create_timer(self.timer_period, self.send_twist)

    def wl_callback(self, msg):
        self.wl = msg.data

    def wr_callback(self, msg):
        self.wr = msg.data

    def send_twist(self):
        twist_msg = Twist()
        twist_msg.linear.x = 0.1  # Set linear velocity to 0.1 m/s
        twist_msg.angular.z = 0.0  # Set angular velocity to 0 rad/s
        self.publisher.publish(twist_msg)


def main(args=None):
    rclpy.init(args=args)
    wheel_subscriber = WheelSubscriber()
    try:
        rclpy.spin(wheel_subscriber)
    except KeyboardInterrupt:
        pass
    finally:
        wheel_subscriber.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
