import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    
    config = os.path.join(
        get_package_share_directory('control_car'),
            
        )

    odometry_node = Node(
        package = 'control_car',
        executable = 'odometry_node',
        output = 'screen',
    )

    controller_node = Node(
        package = 'control_car',
        executable = 'reconstruction',
        output = 'screen'
    )

    rqt_plot_node = Node(
        package = 'rqt_plot',
        executable = 'rqt_plot',
        parameters = [{'args': '/'}] 
    )
    ld = LaunchDescription([odometry_node, controller_node, rqt_plot_node])
    return ld